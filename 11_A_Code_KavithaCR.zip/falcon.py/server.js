const express = require('express');
const bodyParser = require('body-parser');
const { PythonShell } = require('python-shell');
const path = require('path');

const app = express();
const port = 3000;

// Parse JSON bodies
app.use(bodyParser.json());

// Serve the index.html file for the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// POST /sign endpoint
app.post('/sign', (req, res) => {
    const { message } = req.body;
    const options = {
        scriptPath: path.join(__dirname, '/python_scripts'),
        args: [message]
    };
    PythonShell.run('sign.py', options, (err, result) => {
        if (err) {
            console.error('Error:', err);
            res.status(500).json({ error: 'Internal server error' });
        } else {
            const signature = result[0];
            res.json({ signature });
        }
    });
});

// POST /verify endpoint
app.post('/verify', (req, res) => {
    const { message, signature } = req.body;
    const options = {
        scriptPath: path.join(__dirname, '/python_scripts'),
        args: [message, signature]
    };
    PythonShell.run('verify.py', options, (err, result) => {
        if (err) {
            console.error('Error:', err);
            res.status(500).json({ error: 'Internal server error' });
        } else {
            const isValid = result[0] === 'True';
            res.json({ is_valid: isValid });
        }
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
