from flask import Flask, request, jsonify
from falcon_impl import SecretKey, PublicKey  # Import from falcon_impl instead of falcon

app = Flask(__name__)

# Initialize Falcon secret key
sk = SecretKey(128)  # You can choose the desired key size

# Initialize Falcon public key using the secret key
pk = PublicKey(sk)

@app.route("/sign", methods=["POST"])
def sign_message():
    message = request.json.get("message")
    # Sign the message using Falcon's post-quantum cryptography algorithm
    signature = sk.sign(message.encode())
    return jsonify({"signature": signature.hex()})

@app.route("/verify", methods=["POST"])
def verify_signature():
    message = request.json.get("message")
    signature = bytes.fromhex(request.json.get("signature"))
    # Verify the signature using Falcon's post-quantum cryptography algorithm
    is_valid = pk.verify(message.encode(), signature)
    return jsonify({"is_valid": is_valid})

if __name__ == "__main__":
    app.run(debug=True)
