const axios = require('axios');

async function signAndVerify() {
    const message = "Hello, World!";
    const serverUrl = "http://localhost:5000"; // Update with your Flask server URL

    const results = []; // Array to store results

    try {
        // Sign message
        const signResponse = await axios.post(`${serverUrl}/sign`, { message });
        const signature = signResponse.data.signature;
        console.log("Signature:", signature);

        // Verify signature
        const verifyResponse = await axios.post(`${serverUrl}/verify`, { message, signature });
        const isValid = verifyResponse.data.is_valid;
        console.log("Signature is valid:", isValid);

        // Push result to array
        results.push({ signature, isValid });

        // Simulate scenarios where verification might return false
        if (!isValid) {
            // Display "You are not the right person" if the signature is invalid
            console.log("You are not the right person");
        }
    } catch (error) {
        console.error("Error:", error.message);
    }

    // Display results
    console.log("Results:", results);
}

signAndVerify();
